import Cart from "./components/Cart/Cart";
import AddProduct from "./components/Forms/AddProduct";
import React from "react";

function App() {
  return (
    <React.Fragment>
      <Cart />
      <AddProduct />
    </React.Fragment>
  );
}

export default App;
