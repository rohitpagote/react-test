import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { cartActions, fetchData } from "../../store/cart-slice";

const Cart = (props) => {
  const [prodList, setProdList] = useState([]);
  const values = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchData());
  }, []);

  return (
    <React.Fragment>
      <h1>Events Page</h1>
      <ul>
        {values &&
          values.map((d) => {
            return <li key={d.id}>{d.title}</li>;
          })}
      </ul>
    </React.Fragment>
  );
};

export default Cart;
