import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
  name: "cart",
  initialState: {
    items: []
  },
  reducers: {
    add(state, action) {
      const newItem = action.payload;
      state.items.push({
        id: newItem.id,
        title: newItem.title,
        desc: newItem.desc,
        price: newItem.price
      });
    },

    remove(state, action) {
      state.items.remove(state.items.id);
    }
  }
});

export const fetchData = () => {
  fetch("https://dummyjson.com/products")
    .then((res) => res.json())
    .then((data) => {
      console.log(data);
    });
};

export const cartActions = cartSlice.actions;

export default cartSlice;
